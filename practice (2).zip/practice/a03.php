<?php

gd_info();

?>